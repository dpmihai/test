package org.formaria.install;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import org.formaria.aria.helper.SwingWorker;

/**
 *
 * <p> Copyright (c) Formaria Ltd., 2008, This software is licensed under
 * the Lesser GNU Public License (LGPL), please see license.txt for more details. If
 * you make commercial use of this software you must purchase a commercial
 * license from Formaria.</p>
 * @author luano
 */
public class JvmInstaller
{
  private String installedJrePath;
  private String workingDir;
  private JLabel status;
  private Integer exitValue;
  
  private Properties props;
  
  private ResourceBundle language;
  private ResourceBundle config; 
  
  /** Creates a new instance of JvmInstaller */
  public JvmInstaller( Installer installer )
  {
    workingDir = System.getProperty( "user.dir" );
    config = ResourceBundle.getBundle( "config" );
    
    language = installer.language;
    
    try {
      props = new Properties();
      props.load( new FileInputStream( new File( workingDir + "/data/installer.ini" )));
    } 
    catch ( Exception ex )
    {
      ex.printStackTrace();
    }
  }
  
  public boolean installJVM( JLabel statusText )
  {
    status = statusText;
    
    // 1 Check for an existing JVM.
    installedJrePath = getInstalledPath( getConfigInt( "JRE_MIN_MAJOR" ), 
      getConfigInt( "JRE_MIN_MINOR" ), 
      getConfigInt( "JRE_MIN_REVISION" ), 
      getConfigInt( "JRE_MAX_MAJOR" ), 
      getConfigInt( "JRE_MAX_MINOR" ), 
      getConfigInt( "JRE_MAX_REVISION" ));
    if ( installedJrePath == null ) {
      installJre();    
      return true;
    }
    else {
      status.setText( language.getString("1") + installedJrePath );
      doInstall( installedJrePath );
    }
    
    return false;
  }
  
  private int getConfigInt( String key )
  {
    int value = -1;
    try {
      String s = config.getString( key );
      if ( s != null )
        value = Integer.parseInt( s );
    } 
    catch (NumberFormatException ex)
    {
    }

    return value;
  }
  
  private boolean doInstall( String installedJrePath )
  {
    status.setText( language.getString( "2" ));
    loadWebStart();
    
    doLaunch();
    return false;
  }
  
  private boolean doLaunch()
  {
    return false;
  }
  
  /**
   * Get the path to a JRE installation
   * @param majorMin the minimum major version number, or -1 if no limit is neede
   * @param minorMin the minimum minor version number, or -1 if no limit is neede
   * @param revMin the minimum revision number, or -1 if no limit is neede
   *
   * @param majorMax the maximum major version number, or -1 if no limit is neede
   * @param minorMax the maximum minor version number, or -1 if no limit is neede
   * @param revMax the maximum revision number, or -1 if no limit is neede
   */
  private String getInstalledPath( int majorMin, int minorMin, int revMin, int majorMax, int minorMax, int revMax )
  {
    String installedPath = null;
    int latestVersion = 0;
    String keyRoot = "HKEY_LOCAL_MACHINE\\SOFTWARE\\JavaSoft\\Java Runtime Environment";
    Vector results = getRegEntries( "\"" + keyRoot + "\" /s" );
    int numEntries = results.size();    
    for ( int i = 0; i < numEntries; i++ ) {
      String key = results.get( i++ ).toString();      
      int pos = key.indexOf( "Java Runtime Environment" );
      if ( pos > 0 ) {
        pos += "Java Runtime Environment".length() + 1;
        String version = key.substring( pos );
        String parts[] = version.split( "[._]" );
        int majorVersion, minorVersion, revision;
        majorVersion = Integer.parseInt( parts[ 1 ] );
        
        if ( parts.length > 3 )
          minorVersion = Integer.parseInt( parts[ 2 ] );
        else
          minorVersion = 0;
        
        if ( parts.length > 4 )
          revision = Integer.parseInt( parts[ 3 ] );
        else
          revision = 0;
        
        if ((( majorVersion == -1 ) || ( majorVersion >= majorMin )) && (( majorVersion == -1 ) || ( majorVersion <= majorMax ))) {
          if ((( minorMin == -1 ) || ( minorVersion >= minorMin )) && (( minorMax == -1 ) || ( minorVersion <= minorMax ))) {
            if ((( revMin == -1 ) || ( revision >= revMin )) && (( revMax == -1 ) || ( revision <= revMax ))) {
              // Prefer the neweset acceptable version
              int thisVersion = majorVersion * 10000 + minorVersion * 100 + revision;
              if ( thisVersion > latestVersion ) {
                String value = null;
                while ( i < numEntries ) {
                  value = results.get( i++ ).toString().trim();
                  if ( value.startsWith( "JavaHome" )) 
                    break;                  
                }

                installedPath = value.substring( value.indexOf( "REG_SZ" ) + 6 ).trim();
                latestVersion = thisVersion;
              }
            }
          }
        }
      }
    }
    
    return installedPath;
  }
  
  /**
   * Install the JRE
   */
  private void installJre()
  {
    try {
      final String javaInstall = (String)props.get( "jre_installer" );
      status.setText( language.getString("3") );

      SwingWorker worker = new SwingWorker() 
      {
        public Object construct() 
        {
          try {
            Process process = Runtime.getRuntime().exec( workingDir + File.separatorChar + javaInstall );
            process.waitFor();
            exitValue = new Integer( process.exitValue());
          } 
          catch ( Exception ex ) {
            exitValue = new Integer( -1 );
            ex.printStackTrace();
          }

          return exitValue;
        }

        public void finished() 
        {
          int ev = exitValue.intValue();
          if ( exitValue != 0 ) {
            status.setText( language.getString("Error:_") + exitValue );
            message( language.getString("4") );
          }
          else {
            installedJrePath = getInstalledPath( 5, -1, -1, 5, -1, -1 );
            doInstall( installedJrePath );
          }
          status.setText( "" );
        }
      };
      worker.start();
    } 
    catch ( Exception ex ) {
      status.setText( language.getString( "5" ));
      ex.printStackTrace();
    }
  }
  
  private void loadWebStart()
  {
    String launchFile = (String)props.get( "launchFile" );
    String appDir = (String)props.get( "appDir" );
    String userFile = workingDir + File.separatorChar + launchFile;

    String javaHome = getJavaHomeDir();
    launchWebStart( installedJrePath + "/bin/javaws.exe", userFile, workingDir, appDir );
  }
  
  private String getWebstartPath( String javaHome )
  {
    String javaWS;
    javaWS = javaHome + File.separatorChar + "bin" + File.separatorChar + "javaws.exe";
    
    // Prior to Java 5 Javaws was in its own folder
    File file = new File( javaWS );
    if ( !file.exists() )
      javaWS = javaHome + File.separatorChar + "javaws" + File.separatorChar + "javaws.exe";
    
    return javaWS;
  }
  
  private String getRegEntry( String key )
  {
    try {
      Process proc = Runtime.getRuntime().exec( "REG QUERY " + key );
      InputStream is = proc.getInputStream();
      InputStreamReader isr = new InputStreamReader(is);
      BufferedReader br = new BufferedReader(isr);
      String result = "";
      String line;
      
      while ((line = br.readLine()) != null) {
        result += line;
      }
      
      int pos1 = result.indexOf( "\"" );
      int pos2 = result.indexOf( "\"", pos1 + 1 );
      return result.substring( pos1 + 1, pos2 );
      
    }
    catch ( Exception ex ) {
      message( language.getString("6") + ex.getMessage() );
      ex.printStackTrace();
    }
    return null;
  }

  private Vector getRegEntries( String key )
  {
    Vector results = new Vector();
    try {
      Process proc = Runtime.getRuntime().exec( "REG QUERY " + key );
      InputStream is = proc.getInputStream();
      InputStreamReader isr = new InputStreamReader(is);
      BufferedReader br = new BufferedReader(isr);
      String result = "";
      String line;
      
      while (( line = br.readLine()) != null ) {
        line = line.trim();
        results.add( line );
      }
      
      return results;
    }
    catch ( Exception ex ) {
      message( language.getString("6") + ex.getMessage() );
      ex.printStackTrace();
    }
    return null;
  }
  
  private void launchWebStart( String javaWSPath, String jnlpPath, String userDir, String appDir )
  {
    try {
      String webStartCommand = "\"" + javaWSPath + "\"" + " -wait -codebase file:///" + userDir + "\\"+ appDir + " -import " + jnlpPath;
      Process process = Runtime.getRuntime().exec( webStartCommand );
      process.waitFor();
      int exitValue = process.exitValue();
      if ( exitValue != 0 ) 
        status.setText( language.getString("7") );
      else  
        status.setText( language.getString("8") );
      
      int rc = JOptionPane.showConfirmDialog( null, language.getString("9"), language.getString("10"), JOptionPane.YES_NO_OPTION );
      if ( rc == JOptionPane.YES_OPTION )
        Runtime.getRuntime().exec( javaWSPath + " -offline " + jnlpPath );

      status.setText( language.getString("11") );
      SwingWorker worker = new SwingWorker() 
      {
        public Object construct() 
        {
          try {
            Thread.currentThread().sleep( 3000L );
          } 
          catch ( Exception ex ) {
          }

          return null;
        }

        public void finished() 
        {
          System.exit( 0 );
        }
      };
      worker.start();
    }
    catch ( Exception ex ) {
      status.setText( language.getString("12") );
      ex.printStackTrace();
    }
  }
  
  
  private String getJavaHomeDir()
  {
    return System.getProperty( "java.home" );
  }
  
  private void message( String msg )
  {
    JOptionPane dlg = new JOptionPane();
    dlg.showMessageDialog( null, msg );
  }
}
