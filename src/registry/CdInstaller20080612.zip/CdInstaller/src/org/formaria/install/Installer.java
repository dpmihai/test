package org.formaria.install;
import java.awt.BorderLayout;
import java.util.ResourceBundle;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


/**
 *
 * <p> Copyright (c) Formaria Ltd., 2008, This software is licensed under
 * the Lesser GNU Public License (LGPL), please see license.txt for more details. If
 * you make commercial use of this software you must purchase a commercial
 * license from Formaria.</p>
 * @author luano
 */
public class Installer extends JApplet
{
  private JFrame clientFrame;
  public ResourceBundle language;
  public String languageCode = "en";
  
  private WelcomePanel welcomePanel;
  
  /**
   * @param args the command line arguments
   */
  public static void main( String[] args )
  {
    final String[] myArgs = args;
    SwingUtilities.invokeLater( new Runnable() {
      public void run()
      {
        // createSplashScreen();
        loadUI( myArgs );
      }
    });
  }

  /**
   * Do the actual work of loading the UI
   * @param args
   */
  protected static void loadUI( String[] args )
  {
    try {
      String lafName = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
      UIManager.setLookAndFeel( lafName );
    }
    catch ( Exception e ) {
      System.err.println( "Can't set look & feel:" + e );
    }
    
    JFrame frame = new JFrame();
    Installer applet = new Installer( args, frame );
    frame.getContentPane().add( applet );
    frame.validate();
    frame.setVisible( true );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }  

  /** Creates a new instance of Installer */
  public Installer( String[] args, JFrame frame )
  {
    ResourceBundle config = ResourceBundle.getBundle( "config" );
    language = ResourceBundle.getBundle( config.getString( "localizationPath" ) + languageCode );
    
    clientFrame = frame;    
    clientFrame.setTitle( language.getString( "13" ));
    clientFrame.setIconImage( new javax.swing.ImageIcon( getClass().getResource( "/aria_icon.png" )).getImage() );
    
    setLayout( new BorderLayout());
    welcomePanel = new WelcomePanel( this, languageCode );
    add( welcomePanel, BorderLayout.CENTER );
    
    setVisible( true );
    frame.setSize( 640, 400 );
    frame.setLocationByPlatform( true );
  }
  
  public void setLanguage( String code, String languageName )
  {
    languageCode = code;
    language = ResourceBundle.getBundle( "org/formaria/install/" + languageCode );
    
    welcomePanel.setVisible( false );
    
    remove( welcomePanel );
    welcomePanel = new WelcomePanel( this, languageName );
    add( welcomePanel, BorderLayout.CENTER );
  }
}
